package com.example.spring.app.interfaceService;

import java.util.List;
import java.util.Optional;

import com.example.spring.app.modelo.Delito;

public interface InterDelitoService {
    public List<Delito>listar();
    public Optional<Delito>listarId(int id);
    public int save(Delito d);
    public void delete(int id);

}
