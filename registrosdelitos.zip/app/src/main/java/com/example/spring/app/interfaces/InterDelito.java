package com.example.spring.app.interfaces;

import org.springframework.data.repository.CrudRepository;

@SuppressWarnings("rawtypes")
public interface InterDelito extends CrudRepository {

}
