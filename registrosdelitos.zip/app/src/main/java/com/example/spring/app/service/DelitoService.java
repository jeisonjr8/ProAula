package com.example.spring.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.spring.app.interfaceService.InterDelitoService;
import com.example.spring.app.interfaces.InterDelito;
import com.example.spring.app.modelo.Delito;

@Service
public class DelitoService implements InterDelitoService{

    @Autowired
    private InterDelito data;

    @SuppressWarnings("unchecked")
    @Override
    public List<Delito> listar() {
        return (List<Delito>)data.findAll();
    }

    @Override
    public Optional<Delito> listarId(int id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'listarId'");
    }

    @Override
    public int save(Delito d) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'save'");
    }

    @Override
    public void delete(int id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

}
