package com.example.spring.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.spring.app.interfaceService.InterDelitoService;
import com.example.spring.app.modelo.Delito;


@Controller
@RequestMapping
public class Controlador {

    @Autowired
    private  InterDelitoService service;

    @GetMapping("/listar")
    public String listar(Model model) {
        java.util.List<Delito>delitos=service.listar();
        model.addAttribute("delitos", delitos);
        return "index";
    }

}
