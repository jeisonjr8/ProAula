package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.interfaceService.InterDelitoService;
import com.example.demo.interfaces.InterDelito;
import com.example.demo.modelo.Delito;

@Service
public class DelitoService implements InterDelitoService {

    @Autowired
    private InterDelito data;

    @Override
    public List<Delito> listar() {
        return (List<Delito>)data.findAll();
    }

    @Override
    public Optional<Delito> listarId(int id) {
        return data.findById(id);
    }

    @Override
    public int save(Delito d) {
        int res=0;
        Delito delito=data.save(d);
        if(!delito.equals(null)) {
            res=1;
        }
        return 0;
    }

    @Override
    public void delete(int id) {
        data.deleteById(id);
    }
    
}
