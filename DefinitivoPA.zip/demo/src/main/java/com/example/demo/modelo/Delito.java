package com.example.demo.modelo;

import org.springframework.data.annotation.Id;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Table;

@Entity
@Table(name = "delito")
public class Delito {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Id;
    private String descripcion;
    private String tipo_delito;
    private String Lugar;
    private int fecha;

    public Delito() {
    }

    public Delito(int Id, String Lugar, String descripcion, int fecha, String tipo_delito) {
        this.Id = Id;
        this.Lugar = Lugar;
        this.descripcion = descripcion;
        this.fecha = fecha;
        this.tipo_delito = tipo_delito;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipo_delito() {
        return tipo_delito;
    }

    public void setTipo_delito(String tipo_delito) {
        this.tipo_delito = tipo_delito;
    }

    public String getLugar() {
        return Lugar;
    }

    public void setLugar(String Lugar) {
        this.Lugar = Lugar;
    }

    public int getFecha() {
        return fecha;
    }

    public void setFecha(int fecha) {
        this.fecha = fecha;
    }




}
